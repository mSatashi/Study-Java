import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class App {
    public static void main(String[] args){
        Scanner input= new Scanner(System.in);

        // Write a program that reads student scores, gets the best score
        System.out.print("Enter the number of the student: ");
        int studentNum = input.nextInt();
        System.out.printf("Enter %d scores: ", studentNum);
        int[] arrayScores = new int[studentNum];
        for(int i=0;i<arrayScores.length;i++){
            arrayScores[i]= input.nextInt();
        }
        Operation.findGrades(arrayScores);

// create the array of numbers
        System.out.print("Enter 10 random integers betweeen 1 and 100: ");
        int[] numbers = new int[10];
        
        for(int i =0;i<numbers.length;i++){
            numbers[i] = input.nextInt();
        }
// display reversed number
        for(int i =0, j=numbers.length-1;i<numbers.length/2;i++,j--){
            int temp = numbers[i];
            numbers[i] = numbers[j];
            numbers[j] = temp;
        }
        System.out.println(Arrays.toString(numbers));


// this function for finding the count of the numbers in an Array.
        ArrayList<Integer> num = new ArrayList<>();
        boolean key = true;
        int inputnum;
        System.out.println("Enter random integers betweeen 1 and 100: ");
        while(key){
            inputnum = input.nextInt();
            if(inputnum != 0){
                num.add(inputnum);
            }else{
                key = false;
            }
        }
        Operation.countNumbers(num);
        
    }
}
