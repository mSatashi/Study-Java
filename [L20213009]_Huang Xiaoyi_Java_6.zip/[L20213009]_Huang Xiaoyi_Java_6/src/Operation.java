import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;

public class Operation {
    // this is for 7.1
    public static void findGrades(int[] score) {
        int[] studentScore = score;
        int arrlength = studentScore.length;
        int bestValue = getMaxValue(studentScore);
       
        for(int i=0; i<arrlength;i++){
            int student = i+1;
            if(studentScore[i]>= bestValue-40 && studentScore[i] < bestValue-30){
                System.out.println("Student "+student+" score is "+studentScore[i]+"and grade is D");
            }else if(studentScore[i]>= bestValue-30 && studentScore[i] < bestValue-20){
                System.out.println("Student "+student+" score is "+studentScore[i]+"and grade is C");
            }else if(studentScore[i]>= bestValue-20 && studentScore[i] < bestValue-10){
                System.out.println("Student "+student+" score is "+studentScore[i]+"and grade is B");
            }else if(studentScore[i]>= bestValue-10){
                System.out.println("Student "+student+" score is "+studentScore[i]+"and grade is A");
            }else{
                System.out.println("Student "+student+" score is "+studentScore[i]+"and grade is F");
            }
        }
    }
    private static int getMaxValue(int[] studentScore) {
        int maxValue = studentScore[0];
        for(int i=1;i<studentScore.length;i++){
            if(studentScore[i]>maxValue){
                maxValue = studentScore[i];
            }
        }
        return maxValue;
    }
// this is the function for count the frequencies of an array.
    public static void countNumbers(ArrayList<Integer> arrayOfNumber){
        int [] fr = new int [arrayOfNumber.size()];  
        int visited = -1;  
        
        for(int i = 0; i < arrayOfNumber.size(); i++){  
            int count = 1;  
            for(int j = i+1; j < arrayOfNumber.size(); j++){  
                if(Objects.equals(arrayOfNumber.get(i), arrayOfNumber.get(j))){  
                    count++;  
                    //To avoid counting same element again  
                    fr[j] = visited;  
                }  
            }  
            if(fr[i] != visited)  
                fr[i] = count;  
        }
        
        for(int i = 0; i < fr.length; i++){  
            if(fr[i] != visited){
                if(fr[i] == 1){ 
                    System.out.println(arrayOfNumber.get(i) + " Occurs " + fr[i]+ "time");
                }
                else{
                    System.out.println(arrayOfNumber.get(i) + " Occurs " + fr[i]+ "times");  
                }
            }
        } 
    }
}
