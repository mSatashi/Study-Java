public class MultiDimensional {

    private MultiDimensional(){
        throw new IllegalStateException("Utility class");
    }


    public static double sumColumn(double[][]m, int columnIndex) {
        double sum =0;
        for(int j =0; j<m.length;j++) {
            sum += m[j][columnIndex];
        }
        return sum;   
    }

    public static double sumMajorDiagonal(double[][]m) {
        double sum =0;
        for(int i =0;i<m.length;i++){
            sum += m[i][i];
        }

        return sum;
    }

}