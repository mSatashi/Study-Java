import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;
import java.util.LinkedHashMap;
import java.util.Collections;
import java.util.List;

public class WeeklyHours {
    private WeeklyHours() {
        throw new IllegalStateException("Utility class");
    }

    public static void employeesWeeklyHours() {
        int[][] employeeSchedule = {
            {2,4,3,4,5,8,8},
            {7,3,4,3,3,4,4},
            {3,3,4,3,3,2,2},
            {9,3,4,7,3,4,1},
            {3,5,4,3,6,3,8},
            {3,4,4,6,3,4,4},
            {3,7,4,3,8,3,4},
            {6,3,5,9,2,7,9}};
        
        int[] totalHours =new int[8];

        for(int i= 0; i<employeeSchedule.length;i++){
            int weekHour = 0;
            for(int j =0; j< employeeSchedule[i].length;j++){
                weekHour += employeeSchedule[i][j];
            }
            // assign the total week hours in an array
            totalHours[i] = weekHour;
        }
        // create an HashMap of employee and total work hours
        HashMap <Integer,Integer> employeeAndTotal= new HashMap<>();

        for(int i= 0;i<totalHours.length;i++){
            employeeAndTotal.put(i+1, totalHours[i]);
        }
        
        // get all entries by calling entrySet() method of Map
        Set <Entry<Integer,Integer>> entries = employeeAndTotal.entrySet();

        // Create a custom Comparator to srort entries based upon values
        Comparator<Entry<Integer,Integer>> valueComparator = new Comparator<Entry<Integer,Integer>>() {
            @Override
            public int compare(Entry<Integer,Integer> e1, Entry<Integer,Integer> e2){
                return e1.getValue().compareTo(e2.getValue());
            }

        };

        // Sort method needs a list, so let's first conver Set to List in Java
        List<Entry<Integer,Integer>> listOfEntries = new ArrayList<>(entries);

        // sorting HashMap by values using comparator 
        Collections.sort(listOfEntries,valueComparator.reversed());
        LinkedHashMap<Integer,Integer> sortedByValue =new LinkedHashMap<>(listOfEntries.size());
        
        // copying entries from List to Map
        for(Entry<Integer,Integer> entry: listOfEntries){
            sortedByValue.put(entry.getKey(),entry.getValue());
        }

        System.out.println("Total work hours in a week, sorting entries by values in decreasing order: ");
        Set<Entry<Integer,Integer>> entrySortedbyValue =sortedByValue.entrySet();

        for(Entry<Integer,Integer> mapping: entrySortedbyValue){
            System.out.println("Employee "+mapping.getKey()+ " total week hours "+mapping.getValue());
        }
       
    }

}
