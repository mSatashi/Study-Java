import java.util.Scanner;

public class App {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        // create a 3x4 dimensional array  
        double[][] array1 = new double[3][4];
        System.out.println("Enter 3-by-4 maatrix row by row");
        for(int i =0;i < array1.length; i++) {
            for(int j=0; j<array1[i].length;j++) {
                array1[i][j]= sc.nextDouble();
            }
        }
        // print out the result
        for(int i =0;i<4;i++) {
            System.out.println("Sum of the elements at column "+ i +" is "+MultiDimensional.sumColumn(array1, i));
        }
        
        // create n by n Array
        double[][] array2 = new double[4][4];
        System.out.println("Enter 4-by-4 maatrix row by row");
        for(int i =0;i < array2.length; i++) {
            for(int j=0; j<array2[i].length;j++) {
                array2[i][j]= sc.nextDouble();
            }
        }
        // print out the result
        System.out.println("Sum of the elements in the major diagonal is "+MultiDimensional.sumMajorDiagonal(array2));


        //call the class  function imediately
        System.out.println("\n");
        System.out.println("8.3 Display the correct count of all students in increasing order");
        GradeExam.gradeExam();
        
        System.out.println("\n");
        System.out.println("8.4 Employees Weekly Hours in decreasing order");
        WeeklyHours.employeesWeeklyHours();


    }
}
