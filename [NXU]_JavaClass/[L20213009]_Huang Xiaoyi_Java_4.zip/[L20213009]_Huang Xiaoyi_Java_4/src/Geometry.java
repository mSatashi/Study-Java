import java.util.Scanner;

public class Geometry {
    Scanner sc = new Scanner(System.in);
    static final double RAD = 6371.01;
    double d;

    public void distance() {
        System.out.print("Enter point 1 (latitude and longitude) in degrees: ");
        double x1 = sc.nextDouble();
        double y1 = sc.nextDouble();
        System.out.print("Enter point 2 (latitude and longitude) in degrees: ");
        double x2 = sc.nextDouble();
        double y2 = sc.nextDouble();

        // converting degrees into radians

        double y1radians = Math.toRadians(y1);
        double x1radians = Math.toRadians(x1);
        double y2radians = Math.toRadians(y2);
        double x2radians = Math.toRadians(x2);


            //d = radius * arccos(sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2)) 
         d = RAD * Math.acos((Math.sin(x1radians)*Math.sin(x2radians))+(Math.cos(x1radians)
        *Math.cos(x2radians)*Math.cos(y1radians-y2radians)));
        System.out.printf("The distance between the two points is %f km %n",d);
        /* sample input 
        39.55, -116.25
        41.5, 87.37*/

    }

    public double triangleArea(double a, double b, double c){
        double s  =(a+b+c)/2;
        double triangle = s*(s-a)*(s-b)*(s-c);
        return Math.pow(triangle, 0.5);
    }

    public void regularPolygon(){
        System.out.print("input the number of sides: ");
        int n = sc.nextInt();
        System.out.print("enter the side: ");
        float s = sc.nextFloat();
        double area = (n * s*s)/(4*Math.tan(Math.PI/n));
        System.out.printf("The area of the polygon is %f",area);
    }

}
