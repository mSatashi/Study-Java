import java.util.Scanner;

public class Characters {
    Scanner sc = new Scanner(System.in);
    public void numPads(){
        System.out.print("Enter a letter: ");
        String letter = sc.nextLine();

        String charnum = letter.toLowerCase();

        if("a".equals(charnum)|| "b".equals(charnum) || "c".equals(charnum)){
            System.out.println("The corresponding number is 2");

        }else if("d".equals(charnum)|| "e".equals(charnum) || "f".equals(charnum)){
            System.out.println("The corresponding number is 3");

        }else if("g".equals(charnum)|| "h".equals(charnum) || "i".equals(charnum)){
            System.out.println("The corresponding number is 4");

        }else if("j".equals(charnum)|| "k".equals(charnum) || "l".equals(charnum)){
            System.out.println("The corresponding number is 5");

        }else if("m".equals(charnum)|| "n".equals(charnum) || "o".equals(charnum)){
            System.out.println("The corresponding number is 6");

        }else if("p".equals(charnum)|| "q".equals(charnum) || "r".equals(charnum) || "s".equals(charnum)){
            System.out.println("The corresponding number is 7");

        }else if("t".equals(charnum)|| "u".equals(charnum) || "v".equals(charnum)){
            System.out.println("The corresponding number is 8");

        }else if("w".equals(charnum)|| "x".equals(charnum) || "y".equals(charnum) || "z".equals(charnum)){
            System.out.println("The corresponding number is 9");

        }else{
            System.out.println(charnum + " is an invalid input");
        }

    }
}
