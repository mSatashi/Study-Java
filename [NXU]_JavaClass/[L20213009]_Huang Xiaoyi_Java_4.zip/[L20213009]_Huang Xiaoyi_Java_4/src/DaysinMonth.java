import java.util.Scanner;

public class DaysinMonth {
    Scanner input = new Scanner(System.in);
    public void daysinMonth(){

        
        int numberOfDays =0;

        System.out.print("Enter a year: ");
        int year = input.nextInt();

        System.out.print("Enter a month: ");
        String monthofName = input.next();

       

        switch (monthofName) {
            case "Jan":
                numberOfDays = 31;
                break;
            case "Feb":
                if ((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0))) {
                    numberOfDays = 29;
                } else {
                    numberOfDays = 28;
                }
                break;
            case "Mar":
                numberOfDays = 31;
                break;
            case "Apr":
                numberOfDays = 30;
                break;
            case "May":
                numberOfDays = 31;
                break;
            case "Jun":
                numberOfDays = 30;
                break;
            case "Jul":
                numberOfDays = 31;
                break;
            case "Aug":
                numberOfDays = 31;
                break;
            case "Sep":
                numberOfDays = 30;
                break;
            case "Oct":
                numberOfDays = 31;
                break;
            case "Nov":
                numberOfDays = 30;
                break;
            case "Dec":
                numberOfDays = 31;
        }
        System.out.print(monthofName + " " + year + " has " + numberOfDays + " days\n");
    
    }
}
