public class App {
    public static void main(String[] args){
        // 4.2 Great Circle Distance
        Geometry circle1 = new Geometry(); 
        circle1.distance();
        /**
        Answer:
        Enter point 1 (latitude and longitude) in degrees: 39.55 -116.25
        Enter point 2 (latitude and longitude) in degrees: 41.5 87.37
        The distance between the two points is 10691.79183231593
         */
        
        // 4.3 Geography: Estimate Area
            //Atlanta, Georgia 33.7676338 -84.5606903
            // Orlando Florida 28.4811014 -81.4827522
            // Savannah, Georgia 32.0387665 -81.340365
            // Charlotte, North Carolina 35.2028307 -81.1200221

        Geometry dest1 = new Geometry(); 
        dest1.distance();
        double side1 = dest1.d; 

        Geometry dest2 = new Geometry(); 
        dest2.distance();
        double side2 = dest2.d;

        Geometry dest3 = new Geometry();
        dest3.distance();
        double side3 = dest3.d; 

        Geometry area1 = new Geometry();
        double res = area1.triangleArea(side1, side2, side3);
        System.out.println("The estimate triangle area of 3 point is: "+ res +" km.");
        /*** 
         Answer: 
         Estimation Triangle area of three points(Atlanta, Orlando, and Savannah) is: 60266.005442778915 km.
         Estimation Triangle area of three points(Atlaanta, Charlotte, and Savannah) is: 54324.59518317608 km.
          ***/

        // 4.5 Geometry: area of a regular polygon
        Geometry polygon = new Geometry();
        polygon.regularPolygon();
        /**
         * Answer:
         * input the number of sides: 5
         * enter the side: 6.5
         * The area of the polygon is 72.690170
         */


        //  4.15 Phone key pads
        Characters chara = new Characters();
        chara.numPads();
        // 4.17 Days of a month
        DaysinMonth dim = new DaysinMonth();
        dim.daysinMonth();
    }
}
