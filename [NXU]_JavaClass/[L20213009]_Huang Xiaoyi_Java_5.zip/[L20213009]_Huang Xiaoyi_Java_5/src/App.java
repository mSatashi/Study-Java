import java.util.Random;
import java.util.Scanner;
public class App {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        /**
         * 6.1
         */
        System.out.println("6.1 Size Pentagon");
        System.out.println("Please enter the size of pentagon: ");
        int n = 100;
        for(int i=1;i<n;i++){
            if(i%10==0){
                System.out.println(getPentagonNumber(i)+",");
            }else{
                System.out.print(getPentagonNumber(i)+", ");
            }

            
        }
        /**
         * 6.2
         */
        System.out.println("\n 6.2 Sum Digit");
        System.out.println("Please enter the digits: ");

        long input = scan.nextLong();
        System.out.println("Result: ");
        System.out.println(sumDigits(input));
        
        /**
         * 6.17
         */
        System.out.println("\n 6.17 Random Matrix nxn");
        System.out.println("Please enter n: ");

        int matrix = scan.nextInt();
        printMatrix(matrix);
         /**
         * 6.18
         */
        System.out.println("\n 6.18 Check Password");
        System.out.print("enter your password: ");
        String pswd = scan.next();
        checkPassword(pswd);

    }
// function to get pentagon number
    private static int getPentagonNumber(int n) {

        return (n*(3*n-1))/2;
    }
// function to get sum digits of the input
    public static int sumDigits(long a){
        int len = String.valueOf(a).length();
        int res =0;
        long temp =0;
        boolean key = true;
        while(key){
            for(int i=0;i<len;i++){
                temp = a%10;
                res +=temp;
                a =a/10;
            }
        key=false; 
        }

        return res;
    }
    
// function to get matrix n*n with random values 0 and 1
    public static void printMatrix(int n){
        Random r = new Random(); 
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                System.out.print( r.nextInt(2));
            }
            System.out.println();
        }

    }
// function to check if your password is invalid or valid.
    public static void checkPassword(String pass){
        String[] symbols ={"_","-","@","#","$","^","*","(",")","&",">","<","/","?","[","]","+","=","%","!"};
        String[] digits ={"1","2","3","4","5","6","7","8","9","0"};
        int total=0;
        boolean sym = false;
//finding if there is symbols in the password
        for(String item : symbols){
            if(pass.contains(item)){
                sym = true;
                break;
            }
        }
// count how much the digits are
        for(String num:digits){
            if(pass.contains(num)){
                total=+1;
            }
            
        }

        if(pass.length()<8){
            // if password under 8 characters
            System.out.println("Invalid password. ");
        }else{
            if(sym){
                // if password contains except characters and digits
                System.out.println("Invalid password.");
            }else if(total<1){
                // if password didn't have 2 digits
                System.out.println("Invalid password.");
            }else{
                System.out.println("valid password.");
            }
        }
    }


    
}
