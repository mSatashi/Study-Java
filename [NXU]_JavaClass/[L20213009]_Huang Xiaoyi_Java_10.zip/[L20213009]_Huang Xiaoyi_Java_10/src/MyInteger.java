import java.util.stream.IntStream;

public class MyInteger {
    private int value;

    public MyInteger(int myint){
        this.value = myint;
    }

    public int getMyInteger(){
        return value;
    }

    public boolean isEven(){
        return value%2 ==0;
    }
    public boolean isOdd(){
        return value%2 != 0;
    }

    public boolean isPrime(){
       return value > 1 
        && IntStream.rangeClosed(2, (int) Math.sqrt(value))
        .noneMatch(n -> (value % n == 0));
    }

    public static boolean isEven(int even){
        return even%2 == 0;
    }

    public static boolean isOdd(int odd){
        return odd%2 != 0;
    }

    public static boolean isPrime(int prime){
        return prime > 1 
        && IntStream.rangeClosed(2, (int) Math.sqrt(prime))
        .noneMatch(n -> (prime % n == 0));
    }
    public static boolean isEven(MyInteger even){
        return  even.isEven();
    }

    public static boolean isOdd(MyInteger odd){
        return odd.isOdd();
    }

    public static boolean isPrime(MyInteger prime){
        return prime.isPrime();
    }

    public boolean equals(int equal){
        return this.value == equal;
    }
    
    public boolean equals(MyInteger equal){
        return this.value == equal.getMyInteger();
    }

    public static int parseInt(char[] arr){
        String str = String.valueOf(arr);

        int result = 0;

        for (int j = 0; j < str.length(); j++) {

            result += str.charAt(j);
        }

        return result;
    }

    public static int parseInt(String s){
        return Integer.parseInt(s);
    }

}
