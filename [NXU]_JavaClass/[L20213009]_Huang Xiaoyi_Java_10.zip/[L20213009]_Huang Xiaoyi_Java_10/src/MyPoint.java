public class MyPoint {

    private double pointx;
    private double pointy;

    public MyPoint(){
        this.pointx = 0;
        this.pointy = 0;
    }

    public MyPoint(double x, double y){
        this.pointx = x;
        this.pointy = y;
    }

    public double getPointX(){
        return pointx;
    }

    public double getPointY(){
        return pointy;
    }

    public double distance(MyPoint point) {
        return distance(point.pointx, point.pointy);

    }

    public double distance(double x, double y) {
        return Math.sqrt(Math.pow(this.pointx - x, 2) + Math.pow(this.pointy - y, 2));
    }
}
