public class App {
    public static void main(String[] args){
        MyInteger one1 = new MyInteger(4);
        MyInteger two2 = new MyInteger(73);

        System.out.println(one1.isEven());
        System.out.println(one1.isOdd());
        System.out.println(one1.isPrime());
        System.out.println(one1.equals(two2));


        MyPoint point1 = new MyPoint();
        MyPoint point2 = new MyPoint(10,30.5);

        System.out.printf("The distance between p1 and p2 is %.4f", point2.distance(point1));
    }
}
