import java.util.Scanner;

public class QuadEquations{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a, b, c: ");
        double a = sc.nextDouble();
        double b = sc.nextDouble();
        double c = sc.nextDouble();
        double discr = b*b - 4*a*c;
        double r1 = (-b + Math.pow(discr, 0.5))/2*a;
        double r2 = (-b - Math.pow(discr, 0.5))/2*a;

        if(discr == 0){       
            if(r1 > 0){
                System.out.println("The equation have one root: "+ (float) r1);
            }else{
                System.out.println("The equation have one root:"+ (float) r2);
            }
        }else if(discr > 0){
            System.out.println("The equation have two root:"+(float) r1 +" and "+(float) r2);
        }else{
            System.out.println("The equation have no real root");
        }
    }
}