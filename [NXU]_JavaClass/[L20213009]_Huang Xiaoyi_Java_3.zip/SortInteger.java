import java.util.Scanner;

public class SortInteger{
    public static void main(String[] args) {
        /* Write a program that prompts the user to enter three integers
            and display the integers in non-decreasing order */
        Scanner sc = new Scanner(System.in);
        System.out.print("please input three integers number: ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        int temp =0;
        
        for(int i=0;i<3;i++){
            if(c<b){
                temp =c;
                c=b;
                b=temp;
                if(b<a){
                temp =b;
                b=a;
                a=temp;
                }else{
                    System.out.print(a+" "+b+" "+c);
                }
            }else if(b<a){
                temp =b;
                b=a;
                a=temp;
                System.out.print(a+" "+b+" "+c);
            }
        }
    }
}