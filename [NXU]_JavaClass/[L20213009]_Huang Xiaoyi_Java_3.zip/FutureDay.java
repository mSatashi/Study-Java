import java.util.Scanner;

public class FutureDay{
    /* a program that prompts the user to enter an integer for
    today’s day of the week (Sunday is 0, Monday is 1, …, and Saturday is 6).
    Also prompt the user to enter the number of days after today for a future day 
    and display the future day of the week.*/
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] days = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
        System.out.print(" enter today's day: ");
        int daynum = sc.nextInt();
        System.out.print("Enter the number of days elapsed since today: ");
        int dayelapsed = sc.nextInt();
        int res = dayelapsed%7;
        if(daynum+res > 6){
            System.out.print("Today is "+ days[daynum] +" and the future day is "+ days[res-1]);
        }
        else{
            System.out.print("Today is "+ days[daynum] +" and the future day is "+ days[daynum+res]);
        }
        

    }
}