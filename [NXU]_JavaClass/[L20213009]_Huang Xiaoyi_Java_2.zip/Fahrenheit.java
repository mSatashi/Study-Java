import java.util.Scanner;

public class Fahrenheit{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a degree in Celcius = ");
        int celcius = sc.nextInt();

        float fahrenheit = (9f/5.0f) * celcius +32;

        System.out.print(celcius +" Celcius is "+ fahrenheit+" Fahrenheit");
    }
}