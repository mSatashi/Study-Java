import java.util.Scanner;

public class FinancialApp{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the monthly savings amount: ");
        float savings = sc.nextFloat();

        // the first month will be
        float savings_per_months = savings * (1+ 0.00417f);
        
        for(int i=0; i<5;i++){
            savings_per_months = (savings + savings_per_months)*(1+0.00417f);
        }

        System.out.print("After the sixth month, the account value is "+ savings_per_months);
    }
}