import java.util.Scanner;

public class FindYears{
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the minutes in Integer: ");

        int minutes = sc.nextInt();
        int hours = minutes/60;
        int days = hours/24;
        int years = days/365;
        int remainingYears = days % 365;

        System.out.print(minutes+" minutes is approximately "+ years +" Years and "+ remainingYears+" days");
    }
}