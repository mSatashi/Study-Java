import java.util.Scanner;

public class Cylinder{
    static final double PI = 3.141592653589793;
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the radius and length of cylinder: ");
        float radius = sc.nextFloat();
        float length = sc.nextFloat();

        float area = radius * radius * (float)PI;

        // Calculating the Volume of Cylinder
        float vol = area *length;

        System.out.println("The area is "+ area);
        System.out.println("The volume is "+vol);
    }
}