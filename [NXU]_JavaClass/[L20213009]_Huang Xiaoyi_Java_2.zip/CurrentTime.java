import java.util.Scanner;

public class CurrentTime{
    public static void main(String[] args) {
        long totalMiliseconds = System.currentTimeMillis();

        long totalSeconds = totalMiliseconds/1000;
        long currentSecond = totalSeconds % 60;

        long totalMinutes = totalSeconds/60;
        long currentMinutes = totalMinutes % 60;

        long totalHours = totalMinutes/ 60;
        long currentHours = totalHours % 24;

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the time zone offset to GMT: ");

        int timeZone = sc.nextInt();
        currentHours = currentHours + timeZone;

        if(currentHours < 0){
            currentHours = 24 + currentHours;
        }else if(currentHours >24){
            currentHours = currentHours - 24;
        }

        System.out.print("The current time is: "+currentHours+" : "+currentMinutes+" : "+currentSecond);

    }
}