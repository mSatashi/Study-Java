/*
The ComparableCircle class) Define a class named ComparableCircle
that extends Circle and implements Comparable. Draw the UML diagram and
implement the compareTo method to compare the circles on the basis of area.
Write a test class to find the larger of two instances of ComparableCircle objects.
*/ 
public class App {
    public static void main(String[] args) throws Exception {
        Circle c1 = new Circle(8.0);
        ComparableCircle compare = new ComparableCircle(2.5);

        System.out.println(compare.compareTo(c1));
        System.out.println(compare.toString());
    }
}
