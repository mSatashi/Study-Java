


public class ComparableCircle extends Circle implements Comparable<Circle> {

    public ComparableCircle(double radius){
        super(radius);
    }

    @Override
    public int compareTo(Circle o) {
        // TODO Auto-generated method stub
        if( getArea() > o.getArea()){
            return 1;
        }else if (getArea() < o.getArea()){
            return -1;
        }else{
            return 0;
        }
    }

    @Override
    public String toString(){
        return super.toString()+"Area "+getArea();
    }
    
}
