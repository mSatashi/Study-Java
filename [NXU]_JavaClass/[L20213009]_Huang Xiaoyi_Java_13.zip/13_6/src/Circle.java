public class Circle {
    private double r;
    private String color;
    private boolean fill;
    public static final double PHI = 3.14;

    public Circle() {
        this.r = 0;
    }
    public Circle(double radius){
        this.r = radius;
    }
    public Circle(double radius, String color, boolean filled){
        this.r = radius;
        this.color = color;
        this.fill = filled;
    }

    public double getRadius(){
        return r;
    }

    public void setRadius(double radius){
        this.r = radius;
    }

    public double getDiameter(){
        return 2*r;
    }

    public double getArea(){
        return PHI *r*r;
    }
}

